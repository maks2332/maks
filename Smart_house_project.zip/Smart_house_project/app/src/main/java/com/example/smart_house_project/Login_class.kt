package com.example.smart_house_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.GoTrue
import io.github.jan.supabase.postgrest.Postgrest

class Login_class : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_activity)

        val edit_email = findViewById(R.id.email_edit) as EditText
        val edit_pass = findViewById(R.id.password_edit) as EditText
        val btnLog = findViewById(R.id.btn_log_1) as Button
        val btnReg = findViewById(R.id.btn_reg_1) as Button

        val client = createSupabaseClient(
            supabaseUrl = "https://xyzcompany.supabase.co",
            supabaseKey = "public-anon-key"
        ) {
            install(GoTrue)
            install(Postgrest)
            //install other modules
        }
        btnLog.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                val intent = Intent(applicationContext, PIN_reg_class::class.java)
                startActivity(intent)
            }
        })
        btnReg.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                val intent = Intent(applicationContext, Registration_class::class.java)
                startActivity(intent)
            }
        })
        edit_email.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0.isValidEmail()){
                    edit_email.error = null
                }else{
                    edit_email.error = "Введите E-mail."
                }
            }
            override fun afterTextChanged(p0: Editable?) {
            }
        })
        edit_pass.addTextChangedListener(object: TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>0){
                        edit_pass.error = null
                    }else{
                        edit_pass.error = "Нужно ввести пароль."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
            }
        })

    }
}

fun CharSequence?.isValidEmail():Boolean{
    return !isNullOrEmpty() && Patterns
        .EMAIL_ADDRESS.matcher(this).matches()
}