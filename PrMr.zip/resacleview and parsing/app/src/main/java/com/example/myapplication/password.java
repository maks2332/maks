package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class password extends Activity {
    int i = 0;
    String value = "";
    ImageView imageView, imageView1,imageView2, imageView3;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.password_activity);
        Button button1 =findViewById(R.id.b1);
        Button button2 =findViewById(R.id.b2);
        Button button3 =findViewById(R.id.b3);
        Button button4 =findViewById(R.id.b4);
        Button button5 =findViewById(R.id.b5);
        Button button6 =findViewById(R.id.b6);
        Button button7 =findViewById(R.id.b7);
        Button button8 =findViewById(R.id.b8);
        Button button9 =findViewById(R.id.b9);
        imageView3 = findViewById(R.id.imageViewint4);
        imageView1 = findViewById(R.id.imageViewint2);
        imageView2 = findViewById(R.id.imageViewint3);
        imageView = findViewById(R.id.imageViewint1);

    }
    public void onClick(View v){
        switch (v.getId()){
            case R.id.b1:
                value = value + "1";
                break;
            case R.id.b2:
                value = value + "2";
                break;
            case R.id.b3:
                value = value + "3";
                break;
            case R.id.b4:
                value = value + "4";
                break;
            case R.id.b5:
                value = value + "5";
                break;
            case R.id.b6:
                value = value + "6";
                break;
            case R.id.b7:
                value = value + "7";
                break;
            case R.id.b8:
                value = value + "8";
                break;
            case R.id.b9:
                value = value + "9";
                break;
        }
        i++;
        switch(i){
            case 1:
                imageView.setImageResource(R.drawable.ellipse);
                imageView2.setImageResource(R.drawable.ellipse2);
                imageView3.setImageResource(R.drawable.ellipse2);
                imageView1.setImageResource(R.drawable.ellipse2);
            case 2:
                imageView.setImageResource(R.drawable.ellipse2);
                imageView2.setImageResource(R.drawable.ellipse);
                imageView3.setImageResource(R.drawable.ellipse2);
                imageView1.setImageResource(R.drawable.ellipse2);
            case 3:
                imageView.setImageResource(R.drawable.ellipse2);
                imageView2.setImageResource(R.drawable.ellipse2);
                imageView3.setImageResource(R.drawable.ellipse);
                imageView1.setImageResource(R.drawable.ellipse2);
            case 4:
                imageView.setImageResource(R.drawable.ellipse2);
                imageView2.setImageResource(R.drawable.ellipse2);
                imageView3.setImageResource(R.drawable.ellipse2);
                imageView1.setImageResource(R.drawable.ellipse);
        }
        if(i == 4){
            Intent intent = new Intent(this, create_panel.class);
            startActivity(intent);
        }
    }
}