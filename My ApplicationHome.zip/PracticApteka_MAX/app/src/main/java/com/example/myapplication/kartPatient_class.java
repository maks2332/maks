package com.example.myapplication;

import android.app.Activity;
import android.os.Bundle;

public class kartPatient_class extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_activity);
    }
}
